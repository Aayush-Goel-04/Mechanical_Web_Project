import smtplib, ssl
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import pickle  
import filelock
import os
import os.path
import settings



#-----------------------------------------------------------------------------
class SEND_MAIL(object):
  
  def __init__(self):
    #---------- read setting -----------------
    self._path_root = settings.ROOT_DIR
    self._path_data = "%s/%s/" % (self._path_root, settings.MAIL_DIR)
    self._lock = "%s/%s" % (self._path_data, "lock_failed_emails")
    self._filename_failed = "failed_emails.pickle"
    self._sender_password = settings.sender_password
    self._sender_email = settings.sender_email
    self.__set_connection() 

  #-----------------------------------------------------------------------------
  
  
  #-----------------------------------------------------------------------------
  def __set_connection(self):
    port = 465
    context = ssl.create_default_context()
      
    # try sending mail
    server = smtplib.SMTP_SSL("smtp.gmail.com", port, context=context)
    server.login(self._sender_email, self._sender_password)
    
    self._server = server



  #-----------------------------------------------------------------------------
  def __send_email(self, entry):
    subject = entry['subject']
    content = entry['content']
    to_ = entry['to']
    
    #to_ = "ankitj@alumni.cmu.edu"
    #return True
  
    #message
    msg = MIMEMultipart('alternative')
    msg['Subject'] = subject
    msg['From'] = "NetX <%s>" % (self._sender_email)
    msg['To'] = to_
    
    part = MIMEText(content, "html")
    msg.attach(part)

    try:
      receiver_emails  =  [to_] + []
   
      
      # try sending mail
      self._server.sendmail(self._sender_email, receiver_emails, msg.as_string())
     
      # delete the attachments from disk
      #for attach in attachments:
      #  os.system("rm %s" % (attach))
      
      # return succeed
      return True
    
    except:
      return False

  #-----------------------------------------------------------------------------



  #-----------------------------------------------------------------------------
  #-----------------------------------------------------------------------------
  #-----------------------------------------------------------------------------
  #-----------------------------------------------------------------------------
  def add_mail_to_queue(self, subject, content, to_):
    
    self._queue = []
    if os.path.exists("%s/%s" % (self._path_data, self._filename_failed)):
      with filelock.FileLock(self._lock):
        with open("%s/%s" % (self._path_data, self._filename_failed), "rb") as f:
          self._queue = pickle.load(f)
    
    entry = {'subject' : subject,
             'content'  : content,
             'to' : to_}
    self._queue.append(entry)
    
    with filelock.FileLock(self._lock):
      with open("%s/%s" % (self._path_data, self._filename_failed), "wb") as f:
        pickle.dump(self._queue, f)

    return
  #-----------------------------------------------------------------------------


  #-----------------------------------------------------------------------------
  def process_queue(self):


    self._queue = []
    if os.path.exists("%s/%s" % (self._path_data, self._filename_failed)):
      with filelock.FileLock(self._lock):
        with open("%s/%s" % (self._path_data, self._filename_failed), "rb") as f:
          self._queue = pickle.load(f)

    
    _queue = []
    total = len(self._queue)
    for entry in self._queue:
      if self.__send_email(entry):
        continue
      _queue.append(entry)  
    failed = len(_queue)

    with filelock.FileLock(self._lock):
      with open("%s/%s" % (self._path_data, self._filename_failed), "wb") as f:
        pickle.dump(_queue, f)
    
    status = {'total' : total, 'failed' : failed}
    
    return status
  #-----------------------------------------------------------------------------


mails = SEND_MAIL()
mails.process_queue()