from flaskapp import app, db

if __name__ == '__main__':

    # Start App
    app.run(debug=True)