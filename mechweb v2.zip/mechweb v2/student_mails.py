import pickle, os, filelock
from flaskapp.models import Student_Semester
import settings
import os.path

class ADD_MAIL(object):
  
  def __init__(self):
    #---------- read setting -----------------
    self._path_root = settings.ROOT_DIR
    self._path_data = "%s/%s/" % (self._path_root, settings.MAIL_DIR)
    self._lock = "%s/%s" % (self._path_data, "lock_failed_emails")
    self._filename_failed = "failed_emails.pickle"

  #-----------------------------------------------------------------------------
  #-----------------------------------------------------------------------------
  #-----------------------------------------------------------------------------
  #-----------------------------------------------------------------------------
  def add_mails_to_queue(self, entries):
    
    self._queue = []
    if os.path.exists("%s/%s" % (self._path_data, self._filename_failed)):
      with filelock.FileLock(self._lock):
        with open("%s/%s" % (self._path_data, self._filename_failed), "rb") as f:
          self._queue = pickle.load(f)

    for entry in entries:
        newentry = {'subject' : entry['subject'], \
                    'content'  : entry['content'], \
                    'to' : entry['to_']}
        self._queue.append(newentry)

    with filelock.FileLock(self._lock):
      with open("%s/%s" % (self._path_data, self._filename_failed), "wb") as f:
        pickle.dump(self._queue, f)
        f.close()
  
    return
  #-----------------------------------------------------------------------------

addmail = ADD_MAIL()


semester_id = settings.semester_id
students = Student_Semester.query.filter_by(semester_id=semester_id,is_active=1).all()

# Adding entries to the data
entries_ = []
mail_entry = settings.student_mail
URL = settings.WEB_URL+'/student_token'
tout = settings.student_token_timeout
for student in students:
    content = mail_entry['body_'] % (URL,tout['hours'],tout['minutes'])
    entry = {'subject':mail_entry['subject'],
              'to_':student.student.email,
              'content':content}
    entries_.append(entry)
#adding data to file
addmail.add_mails_to_queue(entries_)

