from flask import Flask
from flask_bcrypt import Bcrypt
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from flask_mail import Mail
from flask_apscheduler import APScheduler
import os, filelock, pickle, settings

class Config:
    SCHEDULER_API_ENABLED = True

app = Flask(__name__)
app.config['SECRET_KEY'] = '5791628bb0b13ce0c676dfde280ba245'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = 0
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///site.db'
app.config.from_object(Config())

db = SQLAlchemy(app, session_options={"autoflush": False})
bcrypt = Bcrypt(app)

login_manager = LoginManager(app)
login_manager.login_view = 'login'
login_manager.login_message_category = 'info'

app.config['MAIL_SERVER'] =settings.mail_server
app.config['MAIL_PORT'] = settings.mail_port
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USERNAME'] = settings.sender_email
app.config['MAIL_PASSWORD'] = settings.sender_password
mail = Mail(app)

scheduler = APScheduler()
scheduler.init_app(app)
scheduler.start()

class ADD_MAIL(object):
  
  def __init__(self):
    #---------- read setting -----------------
    self._path_root = settings.ROOT_DIR
    self._path_data = "%s/%s/" % (self._path_root, settings.MAIL_DIR)
    self._lock = "%s/%s" % (self._path_data, "lock_failed_emails")
    self._filename_failed = "failed_emails.pickle"

  #-----------------------------------------------------------------------------
  #-----------------------------------------------------------------------------
  #-----------------------------------------------------------------------------
  #-----------------------------------------------------------------------------
  def add_mails_to_queue(self, entries):
    
    self._queue = []
    if os.path.exists("%s/%s" % (self._path_data, self._filename_failed)):
      with filelock.FileLock(self._lock):
        with open("%s/%s" % (self._path_data, self._filename_failed), "rb") as f:
          self._queue = pickle.load(f)

    for entry in entries:
        newentry = {'subject' : entry['subject'], \
                    'content'  : entry['content'], \
                    'to' : entry['to_']}
        self._queue.append(newentry)
    with filelock.FileLock(self._lock):
      with open("%s/%s" % (self._path_data, self._filename_failed), "wb") as f:
        pickle.dump(self._queue, f)
        f.close()
    return

addmails = ADD_MAIL()
from flaskapp import routes