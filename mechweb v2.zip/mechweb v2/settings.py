WEB_URL = "http://127.0.0.1:5000"

APP_DIR = "flaskapp/"
''' contains path to directory with app files'''
ROOT_DIR = "appdata"
'''contains path to app data directory'''

MAIL_DIR = "mails"  
'''contains path to mail pickle file'''

DATABASE_LOCATION = 'flaskapp/site.db'
'''Database file Location'''

# Mail Configuration
mail_port = 587
mail_server = 'smtp-auth.iitb.ac.in'
sender_email = 'ldap@iitb.ac.in'
sender_password = 'ldap password'

faculty_password_timeout = {'hours':1,'minutes':0}
student_token_timeout = {'hours':1,'minutes':0}

curr_semester_id = 1
'''
    Current Semester in which students are active.\n
    Check available semester_ids by running following lines in terminal opened in root folder.\n
    ---------------------------------------
    from flaskapp.models import Semester

    for sem in Semester.query.all():
        print( sem.id , ' ', sem.semester )
    ---------------------------------------
'''
# Semester Seasons
NEW_SEM = 'Fall'
''' 1st Semester in each institute year'''
SEASONS = {'Fall':'Spring','Spring':'Summer', 'Summer':'Fall',}
''' Defines which semester comes after Fall / Spring / Summer'''

# Default program for students
program = 'Btech'
''' Default program for students if not mentioned'''
# Field for Course Students Facultys
default_field = 'All'
'''Field for entries with no specific field'''
FIELDS = ['TFE','MFG','DES']
ALLFIELDS = FIELDS + ['All']

# Student Categories
CATEGORIES = ['miscellaneous','external','externalgovermentfellowship','instituteta','projectstaff',
            'tap','sponsored','pmrf','foreignnational','selffinance','researchassistant']

# Mails to Faculty that contains login links.
# Don't Change dict keys
faculty_login_mail = {
    'subject':"Faculty login details",
    'body_':"You can login using -\n%s.\n"
            "This link will be valid for "+str(faculty_password_timeout['hours'])+" hours & "+str(faculty_password_timeout['minutes'])+" minutes.\n"
            "If the above link doesnt work use your ldap and password : %s to login at %s.\n"
            "If the link has expired you will need to generate a new link at %s"
}
''' faculty_mail configuration dict : { subject , body }'''

# Mails Send to Faculty After Course Allot.
# Don't Change dict keys
faculty_course_allot_mail = {
    'subject':'TA Allotment by Faculty',
    'body_':"Prof. %s,\n"
            "You can check the courses you have been alloted for Semester : %s at\n"
            "%s\n"
            "Please select Students you would want as Teaching Assistants."
}
''' Faculty course allot mail configuration dict : { subject , body }'''

# Student token mail configuration
# Don't Change dict keys
student_token_mail = {
    'subject' : 'Student Notice',
    'body_' : "Dear Student %s,\nGo to %s to mark attendance or update your details.\nToken will be valid for %s hours & %s minutes"
}
''' Student_token mail configuration dict : { subject , body }'''

# Mail configuration for regular student mails.
# Don't Change dict keys
student_mail = {
    'subject':"Student Notice",
    'body_':"This is a regular reminder to students.\n"
            "Go to %s and generate token link which will be valid for %s hours & %s minutes.\n"
            "Check you profile Data.\n"
            "Check the duties you will have to perform.\n"
            "Mark your Attendance Atleast once a week."
}
''' Mail configuration for regular student mails.
    dict : { subject , body }
'''