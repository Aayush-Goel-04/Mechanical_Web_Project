from functools import wraps
from flask import render_template, send_file, url_for, flash, redirect, request , jsonify
from flaskblog.models import Coordinator_Semester, Course, Course_Faculty, Course_Semester, Course_Ta, Faculty, Faculty_Semester, Semester, Student, Attendance, Student_Semester, Student_token, Facad
from flaskblog.forms import LoginForm
from flaskblog import app, db, bcrypt, scheduler, mail, addmails
from flask_mail import Message
from flask_login import login_required, login_user, current_user, logout_user
import json ,datetime, pytz, string , random, secrets
import pandas as pd
from sqlalchemy.exc import IntegrityError

def coordinator_required(func):
    @wraps(func)
    def decorated_view(*args, **kwargs):
        if current_user.role != 'coordinator':
            flash("You don't have permission to access this resource.", "warning")
            return redirect(url_for("home"))
        return func(*args, **kwargs)
    return decorated_view

def admin_required(func):
    @wraps(func)
    def decorated_view(*args, **kwargs):
        if current_user.role != 'admin':
            flash("You don't have permission to access this resource.", "warning")
            return redirect(url_for("home"))
        return func(*args, **kwargs)
    return decorated_view

def get_fields(s):
    if s==0:
        return ['TFE','MFG','DES','All']
    else:
        return ['TFE','MFG','DES',]

def get_sender():
    return 'goelaayush697@gmail.com'
#
#
# Login Pages 
#
#

@app.route("/")
@app.route("/home")
@login_required
def home():
    return render_template('home.html')

# Login Route
@app.route("/login", methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('home'))
    form = LoginForm()
    if form.validate_on_submit():
        faculty = Faculty.query.filter_by(email = form.email.data).first()
        if faculty and bcrypt.check_password_hash(faculty.password,form.password.data) :
            login_user(faculty, remember=form.remember.data)
            next_page = request.args.get('next')
            return redirect(next_page) if next_page else redirect(url_for('home'))
        else:
            flash('Login Unsuccessful. Please check username and password', 'danger')
    return render_template('login.html', title='Login', form=form)

@app.route("/logout")
def logout():
    logout_user()
    return redirect(url_for('login'))

# Create A Short Time Password For Faculty Login
@app.route("/change_password", methods=['GET','POST'])
def change_password():
    return render_template('password.html')

# Generate Password and schedule app to remove it later
@app.route("/get_password", methods=['GET','POST'])
def get_password():
    ldap = request.form.get('ldap')
    faculty = Faculty.query.filter_by(ldap=ldap).first()

    if faculty == None or faculty.role == 'admin':
        flash('LDAP ID entered doesnt exist !', 'info')
        return redirect(url_for('change_password'))

    # Generating Random Password
    lower = string.ascii_lowercase
    upper = string.ascii_uppercase
    num = string.digits
    password = "".join(random.sample(lower+upper+num,12))
    body_ = 'New Password associated with ldap id '+ldap+' is '+password
    message = Message(subject="New Password", recipients=[faculty.email], 
                        body = body_ , sender= get_sender() )
    print(message)
    # mail.send(message)
    hashed_password = bcrypt.generate_password_hash(password).decode('utf-8')
    faculty.password = hashed_password
    # setting password reset time to 2 hrs
    c_time = datetime.datetime.now(pytz.timezone('Asia/Kolkata'))
    add = datetime.timedelta(hours=2)
    time = c_time + add
    # Scheduling job for password reset
    scheduler.add_job(id='reset_password'+ldap, func=reset_password,
                    trigger='date',run_date=time,args=[faculty.id],replace_existing= True)
    try:
        db.session.commit()
        flash('Password has been sent to '+faculty.email, 'success')
    except Exception:
        db.session.rollback()
    return redirect(url_for('login'))

def reset_password(faculty_id):
    faculty = Faculty.query.get(faculty_id)
    if faculty != None:
        lower = string.ascii_lowercase
        upper = string.ascii_uppercase
        num = string.digits
        symbols = string.punctuation
        password = "".join(random.sample(lower+upper+num+symbols,12))
        hashed_password = bcrypt.generate_password_hash(password).decode('utf-8')
        faculty.password = hashed_password
        db.session.commit()
        print('Password has been reset to '+ password + ' for '+ str(faculty_id))

# Generate Short Token for Student To Use
@app.route("/student_token", methods=['GET', 'POST'])
def student_token():
    return render_template('student_token.html')

@app.route("/get_student_token", methods=['GET','POST'])
def get_student_token():
    roll_number = request.form.get('roll_number')
    student = Student.query.filter_by(roll_number=roll_number).first()
    if student == None:
        flash('Roll Number Doesnt Exist !', 'info')
        return redirect(url_for('student_token'))
    s = Student_token.query.filter_by(student_id=student.id).first()
    if s != None:
        db.session.delete(s)
        db.session.flush()
    token = secrets.token_urlsafe(16)
    student_token = Student_token(student_id=student.id, token=token)
    db.session.add(student_token)
    URL = "http://127.0.0.1:5000/attendance?student_id="+str(student.id)+"&student_token="+token
    body_ = "Dear Student"+str(student.name)+".\n Go to URL "+URL+" to mark attendance and update your details regularly."
    message = Message(subject="Student Profile Page", recipients=[student.email], 
                        body = body_ , sender= get_sender() )
    # mail.send(message)
    print(URL)
    # setting token reset time to 2 hrs
    c_time = datetime.datetime.now(pytz.timezone('Asia/Kolkata'))
    add = datetime.timedelta(hours=2)
    time = c_time + add
    # Scheduling job for password reset
    scheduler.add_job(id='token'+roll_number, func=reset_token,
                    trigger='date',run_date=time,args=[student.id],replace_existing= True)
    try:
        db.session.commit()
        flash('Password has been sent to '+student.email, 'success')
    except Exception:
        db.session.rollback()
    return redirect(url_for('student_token'))

def reset_token(student_id):
    s = Student_token.query.filter_by(student_id=student_id).first()
    if s != None:
        db.session.delete(s)
        db.session.commit()
        print('Token has been reset for '+ str(student_id))

#
#
#
# Admin Access Pages
# Contains Update Data for Course,Student,Faculty
# Select Mandatory Courses and Faculty on Leave for Each Semester
# Assigning Field Coordinators
#
#
#
#


@app.route("/updateData", methods=['GET', 'POST'])
@login_required
@admin_required
def updateData():
    semesters = Semester.query.all()
    fields = get_fields(1)
    facultys = [{'id':faculty.id, 'name':faculty.name} for faculty in Faculty.query.all() if faculty.is_active == 1 and faculty.role != 'admin']
    return render_template('updateData.html', semesters = semesters,fields=fields,facultys=facultys)

# check column names
def missingcolumns(to_check, given):
    given_set = set(given)
    if(len(given) != len(given_set)):
        return True
    for col in to_check:
        print(col)
        if col in given:
            continue
        else:
            return True
    return False

# Uploda Course Data
@app.route("/uploadCourseData", methods=['GET', 'POST'])
@login_required
@admin_required
def uploadCourseData():
    if request.method == 'POST' and "course_file" in request.files:
        file = request.files['course_file']
        data_xls = pd.read_excel(file)
        cols=['field', 'code', 'name']
        if missingcolumns(cols,data_xls.columns):
            flash('Column Names Dont Match', 'Warning')
            return redirect(url_for('updateData'))
        # Course code must be present in each row
        if data_xls['code'].isnull().values.any() or not data_xls['code'].is_unique:
            flash('Identical Course Codes / Course Code not present', 'info')
        else:
            #Creating Field for Courses | Replacing empty Course Names with Course Codes
            fields = get_fields(0)
            data_xls['code'] = data_xls['code'].astype(str)
            data_xls["field"].fillna("All", inplace = True)
            data_xls["name"].fillna(data_xls["code"], inplace = True)
            for i,data in data_xls.iterrows():
                # Checking if course field is pronounced correctly
                field = str(data['field']).strip()
                code = str(data['code']).strip()
                if field in fields:
                    c = Course.query.filter_by(code = code).first()
                    if c:
                        c.name = data['name']
                        c.field = field
                    else:
                        c = Course(field=field,code=code,name=data['name'])
                        db.session.add(c)
                else:
                    db.session.rollback()
                    flash(' Data Not Uploaded, Course Field not recognisable !', 'info')
                    return redirect(url_for('updateData'))
            try:
                db.session.commit()
                flash('Course Data Uploaded Successfully !', 'success')
            except IntegrityError:
                db.session.rollback()
                flash(' Data Not Uploaded Due to Identical Course Codes!', 'info')
    return redirect(url_for('updateData'))

# Upload Faculty Data
@app.route("/uploadFacultyData", methods=['GET', 'POST'])
@login_required
@admin_required
def uploadFacultyData():
    # Same Functionality as upload course Data
    if request.method == 'POST' and "faculty_file" in request.files:
        file = request.files['faculty_file']
        data_xls = pd.read_excel(file)

        cols=['name', 'ldap', 'email', 'field', 'phone_number','status']
        if missingcolumns(cols,data_xls.columns):
            flash('Column Names Dont Match', 'Warning')
            return redirect(url_for('updateData'))

        if data_xls['ldap'].isnull().values.any() or not data_xls['ldap'].is_unique:
            flash('Identical Ldap / Faculty Ldap not present', 'info')
        else:
            fields = get_fields(0)
            data_xls["field"].fillna("All", inplace = True)
            data_xls["name"].fillna(data_xls["ldap"], inplace = True)
            data_xls["email"].fillna(data_xls["ldap"]+'@iitb.ac.in', inplace = True)
            data_xls["phone_number"].fillna("", inplace = True)
            data_xls["status"].fillna('active', inplace = True)
            lower = string.ascii_lowercase
            upper = string.ascii_uppercase
            num = string.digits
            password = "".join(random.sample(lower+upper+num,12))
            hashed_password = bcrypt.generate_password_hash(password).decode('utf-8')  # remove Later
            for i,data in data_xls.iterrows():
                field = str(data['field']).strip()
                ldap = str(data['ldap']).strip()
                if field not in fields:
                    db.session.rollback()
                    flash(' Data Not Uploaded, Field not recognisable !', 'info')
                    return redirect(url_for('updateData'))
                f = Faculty.query.filter_by(ldap = ldap).first()
                curr = 0 if data['status'] == 'inactive' else 1
                if f:
                    if f.role == 'admin':
                        db.session.roll_back()
                        flash(' Cannot Change admin data !', 'info')
                        return redirect(url_for('updateData'))
                    f.name = data['name']
                    f.phone_number = data['phone_number']
                    f.email = data['email']
                    f.field = field
                    f.password = hashed_password
                    f.is_active = curr
                else:
                    f = Faculty(name=data['name'],ldap=ldap,phone_number=data['phone_number'],
                                email=data['email'],field=field,password=hashed_password,is_active=curr)
                    db.session.add(f)
            try:
                db.session.commit()
                flash('Faculty Data Uploaded Successfully !', 'success')
            except IntegrityError:
                db.session.rollback()
                flash(' Data Not Uploaded !', 'info')

    return redirect(url_for('updateData'))

# Updating Student vs Semester Relations Whether student is active or not 
# (Like Stack with latest Semester at top changes entries above the selected semester )
def create_semester_student_status(semester_id,student_id,status,name):
    semesters = Student_Semester.query.filter(Student_Semester.semester_id>=semester_id,Student_Semester.student_id==student_id).all()
    if status=='inactive':
        for semester in semesters:
            db.session.delete(semester)
    else:
        sem_ids = [ sem.id for sem in Semester.query.filter(Semester.id>=semester_id).all()]
        for semester in semesters:
            semester.is_active = 1
            sem_ids.remove(semester.semester_id)
        for sem_id in sem_ids:
            sm = Student_Semester(semester_id=sem_id,student_id=student_id,is_active=1,name=name)
            db.session.add(sm)
    try:
        db.session.commit()
    except:
        db.session.rollback()

# Upload Student Data
@app.route("/uploadStudentData", methods=['GET', 'POST'])
@login_required
@admin_required
def uploadStudentData():
    print(datetime.datetime.now())
    if request.method == 'POST' and "student_file" in request.files and request.form.get('semester'):
        file = request.files['student_file']
        semester_id = request.form.get('semester')
        data_xls = pd.read_excel(file)
        cols=['name', 'email', 'rollno', 'program', 'field', 'status','category']
        print(data_xls.columns,cols)
        if missingcolumns(cols,data_xls.columns):
            flash('Column Names Dont Match', 'Warning')
            return redirect(url_for('updateData'))

        if data_xls['rollno'].isnull().values.any() or not data_xls['rollno'].is_unique:
            flash('Student Roll Number not present or Identical Roll Numbers', 'info')
        else:
            # Data Sanitisation
            fields = get_fields(0)
            data_xls["rollno"] = data_xls['rollno'].astype(str)
            data_xls["field"].fillna("All", inplace = True)
            data_xls["program"].fillna("None", inplace = True)
            data_xls["category"].fillna("", inplace = True)
            data_xls["name"].fillna(data_xls["rollno"], inplace = True)
            data_xls["email"].fillna(data_xls["rollno"]+'@iitb.ac.in', inplace = True)
            data_xls["status"].fillna('active', inplace = True)
            print(datetime.datetime.now())
            for i,data in data_xls.iterrows():
                field = str(data['field']).strip()
                rollno = str(data['rollno']).strip()
                if field not in fields:
                    db.session.rollback()
                    flash(' Data Not Uploaded, Field not recognisable !', 'info')
                    return redirect(url_for('updateData'))
                s = db.session.query(Student).filter(Student.roll_number==rollno).first()
                if s:
                    s.name = data['name']
                    s.email = data['email']
                    s.program = data['program']
                    s.field = field
                else:
                    s = Student(name=data['name'],email=data['email'],roll_number=rollno,program=data['program'],field=field)
                    db.session.add(s)
                db.session.flush()
                create_semester_student_status(semester_id,s.id,data['status'],rollno+' - '+data['name'])
            print(datetime.datetime.now())
            try:
                db.session.commit()
                flash('Student Data Uploaded Successfully !', 'success')
            except IntegrityError:
                db.session.rollback()
                flash(' Data Not Uploaded !', 'info')
    return redirect(url_for('updateData'))

# Create New Semester
@app.route("/createNewSemester")
@login_required
@admin_required
def createNewSemester():
    season = {'Fall':'Spring','Spring':'Summer', 'Summer':'Fall',}
    semester = Semester.query.all()
    if semester:
        year = semester[-1].year
        sem = semester[-1].semester[:-7]
        prev_sem_id = semester[-1].id
        new_sem = season[sem]
        if new_sem == 'Fall':
            year += 1
        sem1 = Semester(semester=new_sem+' - '+str(year),year=year)
    else:
        year = datetime.datetime.today().year
        sem1 = Semester(semester='Fall - '+str(year),year=year)
        db.session.add(sem1)
        db.session.commit()
        flash(sem1.semester+' Semester Created !','success')
        return redirect("/updateData")

    db.session.add(sem1)
    db.session.flush()
    new_sem_id = sem1.id
    if new_sem_id != prev_sem_id+1 :
        db.session.rollback()
        flash('Error !', 'error')
        return redirect("/updateData")
    students = Student_Semester.query.filter_by(semester_id=prev_sem_id,is_active=1).all()
    for student in students:
        sm = Student_Semester(semester_id=new_sem_id,student_id=student.student_id,is_active=1)
        db.session.add(sm)
    try:
        db.session.commit()
        flash(sem1.semester+' Semester Created !','success')
    except:
        db.session.rollback()
        flash('Error !', 'error')
    return redirect("/updateData")

# Send Data for Selecting Facultys on Leave or Mandatory Coruses
@app.route("/semesterData_1", methods=['GET', 'POST'])
@login_required
@admin_required
def semesterData_1():
    facultys = [{'id':faculty.id, 'name':faculty.name} for faculty in Faculty.query.filter(Faculty.is_active==1,Faculty.role!='admin').all()]
    courses = [{'id':course.id, 'name':course.__repr__()} for course in Course.query.all()]
    resp = {'facultys':facultys,'courses':courses}
    return jsonify(resp)

# Create Table for Faculty On Leave and Mandatory Courses Based on Semester Selected
@app.route("/semesterData_2", methods=['GET', 'POST'])
@login_required
@admin_required
def semesterData_2():
    semester_id = request.form.get('semester_id')
    facultys = [{'id':faculty.id,'faculty_id':faculty.faculty_id, 'name':faculty.faculty.name} for faculty in Faculty_Semester.query.filter_by(semester_id=semester_id,is_active=0).all()]
    courses = [{'id':course.id,'course_id':course.course_id, 'course':course.course.__repr__()} for course in Course_Semester.query.filter_by(semester_id=semester_id,is_mandatory=1).all()]
    resp = {'courses':courses,'facultys':facultys}
    return jsonify(resp)

# Marking The selected course as mandatory for the semester
@app.route("/courseMarkMandatory", methods=['GET', 'POST'])
@login_required
@admin_required
def courseMarkMandatory():
    course_id = request.form.get('course_id')
    semester_id = request.form.get('semester_id')
    cs = Course_Semester.query.filter_by(semester_id=semester_id,is_mandatory=1,course_id=course_id).first()
    if cs:
        response = {'message':'Entry already exists'}
    else:
        cs = Course_Semester(course_id=course_id,semester_id=semester_id,is_mandatory=1)
        db.session.add(cs)
        db.session.commit()
        response = {'message': 'Entry Made'}
    return jsonify(response)

# Removing a mandatory course entry
@app.route("/removeMandatoryCourse", methods=['GET', 'POST'])
@login_required
@admin_required
def removeMandatoryCourse():
    cs_id = request.form.get('course_semester_id')
    semester_id = request.form.get('semester_id')
    cs = Course_Semester.query.get_or_404(cs_id)
    response = {}
    if cs and str(cs.semester_id) == semester_id:
        db.session.delete(cs)
        db.session.commit()
        response = {'message':'Entry deleted'}
    return jsonify(response)

# Mark Faculty on Leave
@app.route("/facultyMarkInactive", methods=['GET', 'POST'])
@login_required
@admin_required
def facultyMarkInactive():
    faculty_id = request.form.get('faculty_id')
    semester_id = request.form.get('semester_id')
    fs = Faculty_Semester.query.filter_by(semester_id=semester_id,is_active=0,faculty_id=faculty_id).first()
    if fs:
        response = {'message':'Entry already exists'}
    else:
        fs = Faculty_Semester(faculty_id=faculty_id,semester_id=semester_id,is_active=0)
        db.session.add(fs)
        db.session.commit()
        response = {'message': 'Entry Made'}
    return jsonify(response)

# Remove Faculty Leave Entry
@app.route("/removeFacultyLeave", methods=['GET', 'POST'])
@login_required
@admin_required
def removeFacultyLeave():
    fs_id = request.form.get('faculty_semester_id')
    semester_id = request.form.get('semester_id')
    fs = Faculty_Semester.query.get_or_404(fs_id)
    response = {}
    if fs and str(fs.semester_id) == semester_id:
        db.session.delete(fs)
        db.session.commit()
        response = {'message':'Entry deleted'}
    return jsonify(response)

# Assign Coordinator

# Send Faculty List with Field as All or Selected Field
@app.route("/get_field_coordinators", methods=['GET', 'POST'])
@login_required
@admin_required
def get_field_coordinators():
    semester_id = request.form.get('semester_id')
    field = request.form.get('field')
    facultys = Faculty.query.filter(Faculty.field.in_((field,'All')))
    f_list = []
    for faculty in facultys:
        sem_ids = [sems.id for sems in faculty.semesters]
        if int(semester_id) in sem_ids or faculty.role == 'admin':
            continue
        f_list.append({'id':faculty.id,'name':faculty.name})
    return jsonify(f_list)

# Remember only One coordinator for each field
@app.route("/addCoordinator", methods=['GET', 'POST'])
@login_required
@admin_required
def addCoordinator():
    field = request.form.get('field')
    faculty_id = request.form.get('faculty_id')
    semester_id = request.form.get('semester_id')
    faculty = Faculty.query.get(faculty_id)
    sems = [s.id for s in faculty.semesters]
    if faculty and (faculty.field == field or faculty.field == 'All') and semester_id and int(semester_id) not in sems:
        entry1 = Coordinator_Semester.query.filter_by(field=field,semester_id=semester_id).first()
        entry2 = Coordinator_Semester.query.filter_by(faculty_id=faculty_id,semester_id=semester_id).first()
        if entry1 or entry2:
            message = 'Coordinator already assigned.'
        else:
            faculty.role = 'coordinator'
            new_entry = Coordinator_Semester(field=field,semester_id=semester_id,faculty_id=faculty_id)
            db.session.add(new_entry)
            message = 'Assigned'
    else:
        message = "Faculty's Field and Selected Field Doesn't Match.\nOR\nFaculty on Leave"
    response = {'message':message}
    try:
        db.session.commit()
    except:
        db.session.rollback()
    return jsonify(response)

# Removing The coordinator
@app.route("/removeCoordinator", methods=['GET', 'POST'])
@login_required
@admin_required
def removeCoordinator():
    coordinator_id = request.form.get('coordinator_id')
    coordinator = Coordinator_Semester.query.get(coordinator_id)
    if coordinator and Faculty.query.get(coordinator.faculty_id):
        db.session.delete(coordinator)
        db.session.flush()
        faculty = Faculty.query.get(coordinator.faculty_id)
        if len(faculty.coordinator_sems)==0:
            faculty.role = 'faculty'
        try:
            db.session.commit()
        except:
            db.session.rollback()
    return jsonify()

# Send Data for Coordinators Appointed
@app.route("/coordinatorData", methods=['GET', 'POST'])
@login_required
@admin_required
def coordiantorData():
    semester_id = request.form.get('semester_id')
    coordinators = []
    for field in Coordinator_Semester.query.filter_by(semester_id=semester_id).all():
        coordinators.append({'id':field.id,'faculty_id':field.faculty_id,'name':field.faculty.name,'ldap':field.faculty.ldap,
                            'field':field.field,'faculty_field':field.faculty.field})
    response = {'coordinators': coordinators}
    return jsonify(response)

#
#
#
# Admin Acess page to Download Data
#
#
#
#


@app.route("/downloadData", methods=['GET', 'POST'])
@login_required
@admin_required
def downloadData():
    semesters = Semester.query.all()
    return render_template('downloadData.html', semesters = semesters)

@app.route("/downloadSemCourseAllot", methods=['GET', 'POST'])
@login_required
@admin_required
def downloadSemCourseAllot():
    sem_id = request.args.get('download_sem_1')
    sem = Semester.query.get(sem_id)
    if not sem_id:
        return redirect(url_for('downloadData'))
    path = 'files/course_allot_'+sem.semester+'.xlsx'
    course_facultys = Course_Faculty.query.filter_by(semester_id=sem_id).all()
    course_allot = pd.ExcelWriter('flaskblog/'+path)
    courses = []
    for c in course_facultys:
        courses.append({'Field':c.course.field,'Code':c.course.code,'Name':c.course.name,'Section':c.section,
                        'Ldap':c.faculty.ldap,'Faculty':c.faculty.name,'Max TAs':c.maxTA})
    df = pd.DataFrame(courses)
    df.to_excel(course_allot, sheet_name='Sheet1', index=False)
    course_allot.save()
    return send_file(path,as_attachment=True)

@app.route("/downloadSemTAAllot", methods=['GET', 'POST'])
@login_required
@admin_required
def downloadSemTAAllot():
    sem_id = request.args.get('download_sem_2')
    sem = Semester.query.get(sem_id)
    if not sem_id:
        return redirect(url_for('downloadData'))
    path = 'files/TA_allot_'+sem.semester+'.xlsx'
    course_Tas = Course_Ta.query.filter_by(semester_id=sem_id).all()
    ta_allot = pd.ExcelWriter('flaskblog/'+path)
    tas = []
    for c in course_Tas:
        tas.append({'Field':c.course.field,'Code':c.course.code,'Name':c.course.name,'Section':c.section,
                    'roll_no':c.ta.roll_number,'name':c.ta.name})
    df = pd.DataFrame(tas)
    df.to_excel(ta_allot, sheet_name='Sheet1', index=False)
    ta_allot.save()
    return send_file(path,as_attachment=True)

@app.route("/downloadStudentAttendanceList", methods=['GET', 'POST'])
@login_required
@admin_required
def downloadStudentAttendanceList():
    days = request.args.get('days')
    sem_id = request.args.get('download_sem_3')
    if not (days and sem_id):
        return redirect(url_for('downloadData'))
    days = int(days)
    path = 'files/absentStudentsList.xlsx'
    s_list = pd.ExcelWriter('flaskblog/'+path)
    students = Student_Semester.query.filter_by(semester_id=sem_id, is_active=1).all()
    absent = []
    for s in students:
        attendance = s.student.attendance
        if attendance:
            c_time = datetime.datetime.now(pytz.timezone('Asia/Kolkata')).date() - attendance[-1].date_posted
            last_attendance = str(c_time.days) + ' Days Ago'
        else:
            absent.append({'Roll_no':s.student.roll_number,'Name':s.student.name,'Email':s.student.email,'Last Attendance':'None'})
            continue
        if c_time.days > days:
            absent.append({'Roll_no':s.student.roll_number,'Name':s.student.name,'Email':s.student.email,'Last Attendance':last_attendance})
    df = pd.DataFrame(absent)
    df.to_excel(s_list, sheet_name='Sheet1', index=False)
    s_list.save()
    return send_file(path,as_attachment=True)


#
#
#
# Admin and Coordinator Access Pages
# Includes Course Allotment, TA Allotment
#
#
# Course Allotment By Coordinators and Admin
# ******************************************
#
#
#


@app.route("/courseAllotment", methods=['GET', 'POST'])
@login_required
@coordinator_required
def courseAllotment():
    coordinator_sems = Coordinator_Semester.query.filter_by(faculty_id=current_user.id).all()
    semesters = [{'id':sem.semester_id,'semester':sem.semester.__repr__(),'field':sem.field} for sem in coordinator_sems]
    return render_template('courseAllotment.html', title='Course Allotment', semesters=semesters)

# Getting Courses Based on Coordinator Field
@app.route("/get_courses", methods = ["GET","POST"])
@login_required
@coordinator_required
def get_courses():
    field = request.form.get('field')
    courses = [{'id':course.id,'name':course.__repr__()} for course in Course.query.filter(Course.field.in_((field,'All')))]
    return jsonify(courses)

# Removing Course Allotment
@app.route("/removeCourseAllotment", methods=['GET', 'POST'])
@login_required
@coordinator_required
def removeCourseAllotment():
    fac_id = request.form.get('course_faculty_id')
    semester_id = request.form.get('semester_id')
    cf = Course_Faculty.query.get(fac_id)
    if cf and str(cf.semester_id) == semester_id :
        db.session.delete(cf)
        resp = {'message': "success"}
    else:
        resp = {'message': "error"}
    db.session.commit()
    return jsonify(resp)

# Sending All the Course Allotments and Mandatory Courses List based on selected Semester
@app.route("/get_course_allotments", methods = ["GET","POST"])
@login_required
@coordinator_required
def get_course_allotments():
    field = request.form.get('field')
    semester_id = request.form.get('semester_id')
    course_ids = [course.id for course in Course.query.filter(Course.field.in_((field,'All')))]
    c_list = [None]*(1+max(course_ids))
    for i in course_ids:
        c_list[i]=0
    course_facultys = Course_Faculty.query.filter(Course_Faculty.semester_id==semester_id).all()
    course_fac_list = []
    course_list = []
    for course_faculty in course_facultys:
        if c_list[course_faculty.course_id] is None:
            continue
        course_fac_list.append({'id': course_faculty.id,
                    'field':course_faculty.course.field,
                    'course': course_faculty.course.__repr__(),
                    'section': course_faculty.section,
                    'professor': course_faculty.faculty.__repr__(),
                    'maxTA':course_faculty.maxTA})
        c_list[course_faculty.course_id] += 1
    for course in Course_Semester.query.filter(Course_Semester.semester_id==semester_id).all():
        if c_list[course.course_id] is None:
            continue
        course_list.append({'field':course.course.field,'course_id':course.course_id,
                    'course': course.course.__repr__(),
                    'allotments':c_list[course.course_id]})
    response = {'fac_list':course_fac_list,'course_list':course_list}
    return jsonify(response)

# Displaying Current and Previous Semester Allotments of the selected Course
@app.route("/get_alloted_sections", methods = ["GET","POST"])
@login_required
@coordinator_required
def get_alloted_sections():
    course_id = request.form.get('course_id')
    semester_id = int(request.form.get('semester_id'))
    query = Course_Faculty.query.filter_by(course_id=course_id).all()
    course_sections = []
    prev_allot = {}
    for q in query:
        if q.semester_id == semester_id:
            course_sections.append({'section':q.section,'prof':q.faculty.name,'maxTA':q.maxTA})
        else:
            if q.faculty.name in prev_allot:
                if q.semester.__repr__() not in prev_allot[q.faculty.name]:
                    prev_allot[q.faculty.name] = prev_allot.get(q.faculty.name,'')+ ' | ' + q.semester.__repr__()
            else:
                prev_allot[q.faculty.name] = prev_allot.get(q.faculty.name,'')+ q.semester.__repr__()
    resp = {'course_sections':course_sections,'previous_allotments':prev_allot}
    return jsonify(resp)

# Getting Sections and Lists of Faculty after Selecting Number of Sections to Add
@app.route("/get_sections_and_faculty", methods = ["GET","POST"])
@login_required
@coordinator_required
def get_sections_and_faculty():
    semester_id,course_id = request.form.get('semester_id'),request.form.get('course_id')
    field,num_sections = request.form.get('field'),int(request.form.get('num_sections'))
    course_sections = [q.section for q in Course_Faculty.query.filter_by(course_id=course_id,semester_id=semester_id).all()]
    # get new sections that are to be alloted
    new_sections = []
    for i in range(1,num_sections+len(course_sections)+1):
        section = 'S'+str(i)
        if section not in course_sections:
            new_sections.append(section)
    facultys = []
    for fac in Faculty.query.filter(Faculty.field.in_(('All',field)),Faculty.is_active==1,Faculty.role!='admin').all():
        fs = [sem.id for sem in fac.semesters]
        if semester_id in fs:
            continue
        facultys.append({'name':fac.name,'id':fac.id}) 
    response = {'sections':new_sections,'profs':facultys}
    # Get next sections
    return jsonify(response)

# Making Course Allotment
@app.route("/allot_section_fac", methods = ["GET","POST"])
@login_required
@coordinator_required
def allot_section_fac():
    section_faculty_list = json.loads(request.form.get('section_faculty_list'))
    course_id,semester_id = request.form.get('course_id'),request.form.get('semester_id')
    for ta in section_faculty_list:
        section,faculty_id,maxTAs = ta['section'],ta['faculty_id'],ta['maxTA']
        if faculty_id and maxTAs and section:
            new_entry = Course_Faculty(faculty_id=faculty_id,course_id=course_id,section=section,maxTA=maxTAs,semester_id=semester_id)
            db.session.add(new_entry)
            resp = {'message': 'Entry done'}
        else:
            resp = {'message': 'Entry Not Done, Duplicate or Empty Entries'}
            db.session.rollback()
            return jsonify(resp)
    db.session.commit()
    return jsonify(resp)

# Send Mails to Faculty Belongin to [Coordinator Field , All]
@app.route("/sendMailFaculty/<semester_id>", methods = ["GET","POST"])
@login_required
@coordinator_required
def sendMailFaculty(semester_id):
    cs = Coordinator_Semester.query.filter_by(semester_id=semester_id,faculty_id=current_user.id).first()
    semester = Semester.query.get(semester_id).__repr__()
    cnt = 0
    mails_to_send = []
    for faculty in Faculty.query.filter(Faculty.field.in_((cs.field,'All')),Faculty.is_active==1).all():
        URL = "http://127.0.0.1:5000/login"
        body_ = "Prof. "+ faculty.name +" ,You can check the courses you have been alloted for Semester : "+semester+" by going to "+ URL +".\nPlease select Students you would want as Teaching Assistants."
        # mail.send(message)
        entry = {'subject':"TA Allotments by Faculty",'to_':faculty.email,'content':body_}
        cnt += 1
        mails_to_send.append(entry)
    addmails.add_mails_to_queue(mails_to_send)
    flash(str(cnt) +' Mails Sent !', 'success')
    return redirect(url_for('courseAllotment'))

#
#
#
# TA Allotment by Coordinators and Admin
# ***************************************
#
#
#


@app.route("/studentAllotment", methods=['GET', 'POST'])
@login_required
@coordinator_required
def studentAllotment():
    coordinator_sems = Coordinator_Semester.query.filter_by(faculty_id=current_user.id).all()
    semesters = [{'id':sem.semester_id,'semester':sem.semester.__repr__(),'field':sem.field} for sem in coordinator_sems]
    return render_template('studentAllotment.html', title='Student Allotment',semesters=semesters)

# get_courses route is same as get_courses route for faculty allotment

# Getting Allotments of Selected Course and Semester
@app.route("/get_section_tas", methods = ["GET","POST"])
@login_required
@coordinator_required
def get_section_tas():
    course_id = request.form.get('course_id')
    semester_id = request.form.get('semester_id')
    section = request.form.get('section')
    course_tas = []
    for c in Course_Ta.query.filter(Course_Ta.course_id==course_id,
                    Course_Ta.semester_id==semester_id,Course_Ta.section==section).all():
        course_tas.append({'id':c.id, 'section':c.section,'student':c.ta.__repr__()})
    resp = {'course_tas':course_tas,'course':Course.query.get(course_id).__repr__()}
    return jsonify(resp)

# Getting All Allotments Made and Pending Allotments Table For selected Semester
@app.route("/get_student_allotments", methods = ["GET","POST"])
@login_required
@coordinator_required
def get_student_allotments():
    semester_id = request.form.get('semester_id')
    field = request.form.get('field')
    course_ids = [course.id for course in Course.query.filter(Course.field.in_((field,'All')))]
    c_list = [None]*(max(course_ids)+1)
    s_list = [None]*(max(course_ids)+1)
    for i in course_ids:
        c_list[i]=1
    ta_list = []
    allotments = []  # Contains number of left to be alloted out of Max TAs allowed
    for course_ta in Course_Ta.query.filter(Course_Ta.semester_id==semester_id).all():
        if c_list[course_ta.course_id] is None:
            continue
        if s_list[course_ta.course_id] is None:
            a = {}
        else:
            a = s_list[course_ta.course_id]
        if course_ta.section in a:
            a[course_ta.section]+=1
        else:
            a[course_ta.section] = 1
        s_list[course_ta.course_id] = a
        ta_list.append({'id': course_ta.id,
                    'field':course_ta.course.field,
                    'course':course_ta.course.__repr__(),
                    'section': course_ta.section,
                    'student': course_ta.ta.name})
    for c in Course_Faculty.query.filter(Course_Faculty.semester_id==semester_id).all():
        if c_list[c.course_id] is None:
            continue
        a = s_list[c.course_id]
        if a is None:
            done = 0
        else:
            done = a.get(c.section,0)
        allotments.append({'course_id':c.course_id,'course':c.course.code,'max':c.maxTA,
                    'section_id':int(c.section[1:]),'section':c.section +' - '+ c.faculty.name,
                    'done':done})
    response = {'ta_list': ta_list,'pending_allotments':allotments}
    return jsonify(response)

# Remove TA Allotments
@app.route("/removeTaAllotment", methods=['GET', 'POST'])
@login_required
def removeTaAllotment():
    ta_id = request.form.get('ta_id')
    semester_id = int(request.form.get('semester_id'))
    ct = Course_Ta.query.get(ta_id)
    if ct and ct.semester_id == semester_id:
        db.session.delete(ct)
        resp = {'message': "success"}
    else:
        resp = {'message': "error"}
    db.session.commit()
    return jsonify(resp)

# Finding The Sections Under Selected Course
@app.route("/get_sections_fortaallot", methods = ["GET","POST"])
@login_required
@coordinator_required
def get_sections_fortaallot():
    course_id = request.form.get('course_id')
    semester_id = request.form.get('semester_id')
    query = Course_Faculty.query.filter(Course_Faculty.course_id==course_id,
                        Course_Faculty.semester_id==semester_id).all()
    course_sections = []
    for q in query:
        course_sections.append({'section':q.section,'prof':q.faculty.name,'maxTA':q.maxTA})
    resp = {'course_sections':course_sections}
    return jsonify(resp)

# Finding the student list based on field
@app.route("/get_students_fortaallot", methods = ["GET","POST"])
@login_required
@coordinator_required
def get_students_fortaallot():
    semester_id = request.form.get('semester_id')
    field = request.form.get('field')
    student_ids = [s.student_id for s in db.session.query(Student_Semester).filter(Student_Semester.semester_id==semester_id).all()]
    cnt = [None]*(max(student_ids)+1)
    for id in student_ids:
        cnt[id] = 0
    for course_ta in Course_Ta.query.filter(Course_Ta.semester_id==semester_id).all():
        if cnt[course_ta.student_id] is not None:
            cnt[course_ta.student_id] += 1
    student_list = []
    for s in Student.query.filter(Student.field.in_((field,'All'))):
        if cnt[s.id] is None:
            continue
        student_list.append({'id':s.id,'name':s.__repr__(),'cnt':cnt[s.id]})
    resp = {'student_list':student_list}
    return jsonify(resp)


# Making TA Allotment by Checking Max TA Limit for the Selected Section
@app.route("/allot_section_ta", methods = ["GET","POST"])
@login_required
def allot_section_ta():
    ta = json.loads(request.form.get('ta_list'))
    semester_id,field,course_id,section,student_id = int(ta['semester_id']),ta['field'],int(ta['course_id']),ta['section'],int(ta['student_id'])

    # Make an Entry Check in Database
    entry_check = Course_Ta.query.filter_by(course_id=course_id, student_id=student_id, section=section,semester_id=semester_id).first()
    if entry_check:
        response = {'message': 'Student has already been alloted under this Course and Section','success':False}
        return jsonify(response)

    # Verifying student , course sections existence and if max TAs Limit is reached or not
    student = Student_Semester.query.filter_by(student_id=student_id,semester_id=semester_id,is_active=1).first()
    course_faculty = Course_Faculty.query.filter_by(course_id=course_id, section=section, semester_id=semester_id).first()
    allTAs = Course_Ta.query.filter_by(course_id=course_id, section=section, semester_id=semester_id).count()
    response = {}
    c = Course.query.get(course_id)
    success = False
    if allTAs >= course_faculty.maxTA:
        response = {'message': 'Maximum TAs Limit Reached'}
        return jsonify(response)
    if student and semester_id and course_id and section and student_id:
        if student.student.field in ['All',field]:
            entry = Course_Ta(course_id=course_id, student_id=student_id, section=section,semester_id=semester_id)
            db.session.add(entry)
            db.session.commit()
            response = {'message': 'Student is alloted'}
            success = True
        else:
            response = {'message': "Student Field and Course Field Doesn't Match"}
    response['success'] = success
    return jsonify(response)

#
#
#
# Faculty Access Routes
# *********************
#
# TA allotment by Faculty
# ************************
#
# List of Students With Faculty as Faculty Advisor
# ************************************************
#
#
#

@app.route("/studentAllotmentFac", methods=["GET","POST"])
@login_required
def studentAllotmentFac():
    faculty = Faculty.query.get(current_user.id)
    semesters = Semester.query.all()
    return render_template('studentAllotmentFac.html',semesters=semesters,faculty=faculty)

# Getting List of alloted Courses to the Faculty for the Semester and Student List
@app.route("/get_faculty_courses", methods = ["GET","POST"])
@login_required
def get_faculty_courses():
    semester_id = request.form.get('semester_id')
    course_query = Course_Faculty.query.filter_by(faculty_id=current_user.id,semester_id=semester_id).all()
    courses = []
    for c in course_query:
        courses.append({'id':c.course_id,'field':c.course.field,'name':c.course.__repr__(),
                        'section':c.section,'maxTA':c.maxTA,
                        'done':Course_Ta.query.filter_by(section=c.section,semester_id=semester_id,course_id=c.course.id).count()})
    resp = {'courses':courses}
    return jsonify(resp)

# Getting List of Students that can take the course selected by faculty
@app.route("/get_faculty_students", methods = ["GET","POST"])
@login_required
def get_faculty_students():
    semester_id = request.form.get('semester_id')
    field = current_user.field
    student_ids = [s.student_id for s in db.session.query(Student_Semester).filter(Student_Semester.semester_id==semester_id).all()]
    cnt = [None]*(max(student_ids)+1)
    for id in student_ids:
        cnt[id] = 0
    for course_ta in Course_Ta.query.filter(Course_Ta.semester_id==semester_id).all():
        if cnt[course_ta.student_id] is not None:
            cnt[course_ta.student_id] += 1
    student_list = []
    for s in Student.query.filter(Student.field.in_((field,'All'))):
        if cnt[s.id] is None:
            continue
        student_list.append({'id':s.id,'name':s.__repr__(),'cnt':cnt[s.id]})
    resp = {'student_list':student_list}
    return jsonify(resp)

# remove allotment route used, is same as removeTaAllotment route mention above

# Getting List of Students Alloted Under That Facultys Courses
@app.route("/get_fac_ta_data", methods = ["GET","POST"])
@login_required
def get_fac_ta_data():
    semester_id = request.form.get('semester_id')
    course_query = Course_Faculty.query.filter_by(faculty_id=current_user.id,semester_id=semester_id).all()
    courses = [{'id':c.course_id,'field':c.course.field,'name':c.course.__repr__(), 'section':c.section} for c in course_query]
    ta_list = []
    for course in courses:
        tas = Course_Ta.query.filter_by(course_id=course['id'], section=course['section'],semester_id=semester_id).all()
        for ta in tas:
            ta_list.append({'id':ta.id, 'course':course['name'], 'section':course['section'],
                            'student':ta.ta.__repr__(),'student_id':ta.student_id,'field':course['field']})
    response = { 'ta_list':ta_list}
    return jsonify(response)

# same route is used as allot_section_ta for TA Allotment by admin
@app.route("/allot_section_ta_byfac", methods = ["GET","POST"])
@login_required
def allot_section_ta_byfac():
    semester_id,course_id = request.form.get('semester_id'),request.form.get('course_id')
    section,student_id = request.form.get('section'),request.form.get('student_id')
    print(semester_id,course_id,section,student_id)
    # Make an Entry Check in Database
    entry_check = Course_Ta.query.filter_by(course_id=course_id, student_id=student_id, section=section,semester_id=semester_id).first()
    if entry_check:
        response = {'message': 'Student has already been alloted under this Course and Section','success':False}
        return jsonify(response)

    # Verifying student , course sections existence and if max TAs Limit is reached or not
    student = Student_Semester.query.filter_by(student_id=student_id,semester_id=semester_id,is_active=1).first()
    course_faculty = Course_Faculty.query.filter_by(course_id=course_id, section=section, semester_id=semester_id).first()
    allTAs = Course_Ta.query.filter_by(course_id=course_id, section=section, semester_id=semester_id).count()
    response = {}
    success = False
    if allTAs >= course_faculty.maxTA:
        response = {'message': 'Maximum TAs Limit Reached'}
        return jsonify(response)
    if student and semester_id and course_id and section and student_id:
        if student.student.field in ['All',current_user.field]:
            entry = Course_Ta(course_id=course_id, student_id=student_id, section=section,semester_id=semester_id)
            db.session.add(entry)
            db.session.commit()
            response = {'message': 'Student is alloted'}
            success = True
        else:
            response = {'message': "Student Field and Course Field Doesn't Match"}
    response['success'] = success
    return jsonify(response)


# Students's Faculty Advisor List
@app.route("/facFacad", methods=["GET","POST"])
@login_required
def facFacad():
    faculty = Faculty.query.get(current_user.id)
    facad_students = Facad.query.filter_by(facad_id=current_user.id).all()
    facad_students_list = []
    for student in facad_students:
        facad_students_list.append({'id':student.id,'student_id':student.student_id,'name': student.student.name,
                                'roll_number':student.student.roll_number,
                                'program':student.student.program, 'field':student.student.field,
                                'status':student.status,'sno':len(facad_students_list)+1})
    return render_template('facFacad.html',facads = facad_students_list,
                            faculty={'name':faculty.name,'id':faculty.id})

# Remove Facad Allotment
@app.route("/facRemoveFacad<faculty_id><id>", methods=["GET","POST"])
@login_required
def facRemoveFacad(faculty_id,id):
    facad = Facad.query.get(id=id)
    if facad and str(current_user.id) == faculty_id and facad.faculty_id == faculty_id:
        db.session.delete(facad)
        db.session.commit()
    return redirect(url_for('facFacad'))

#
#
#
# Student , Faculty, Course List and  Data Pages
# **********************************************
#
#
#

# Get Student List
@app.route("/studentList")
@login_required
def studentList():
    semester = Semester.query.all()
    students = [{'id':student.id,'name':student.__repr__()} for student in Student.query.all()]
    return render_template("studentList.html", students=students,semesters=semester)

# Get Student List Based on Semester
@app.route("/get_student_list", methods=["GET","POST"])
@login_required
def get_student_list():
    semester_id = request.form.get('semester_id')
    student_ids = [s.student_id for s in Student_Semester.query.filter_by(semester_id=semester_id,is_active=1).all()]
    n = max(student_ids)+1
    ta_list = [None]*(n)
    student_facads = [None]*(n)
    for ta in Course_Ta.query.filter_by(semester_id=semester_id).all():
        a = ta_list[ta.student_id]
        if a is None:
            a = []
        a.append(ta)
        ta_list[ta.student_id] = a
    for facad in Facad.query.all():
        a = student_facads[facad.student_id]
        if a is None:
            a = []
        a.append(facad)
        student_facads[facad.student_id] = a
    student_list = []
    current_time = datetime.datetime.now(pytz.timezone('Asia/Kolkata')).date()
    for student_id in student_ids:
        s = Student.query.get(student_id)
        #getting course list student is part of
        courses = []
        tas = ta_list[student_id]
        if tas is None:
            tas = []
        for ta in tas:
            courses.append({'id':ta.course_id,'section':ta.section,'course':ta.course.__repr__()})
        # getting latest attendance
        attendance = ""
        if s.last_attendance:
            c_time = current_time - s.last_attendance
            attendance = str(c_time.days) + ' Days Ago'
        #getting facads names
        facad_list = []
        facads = student_facads[student_id]
        if facads is None:
            facads = []
        for facad in facads:
            facad_list.append({'facad_id':facad.facad_id,'status':facad.status,'facad':facad.facad.name})
        student_list.append({'id': s.id, 'name': s.name, 'email':s.email,'category':s.category,
                             'rollno':s.roll_number, 'phone_number':s.phone_number,
                             'program':s.program, 'field':s.field,'courses': courses,
                             'facads':facad_list,'attendance':attendance})
    resp = {'students':student_list}
    return jsonify(resp)

# Find Student Using Name / Roll_number
@app.route("/findStudent" , methods=['GET', 'POST'])
@login_required
def findStudent():
    student_id = request.args.get('student')
    return redirect(url_for('studentData',student_id=student_id))

# Student Profile Page
@app.route("/studentData/<student_id>")
@login_required
def studentData(student_id):
    student = Student.query.get_or_404(student_id)
    course_tas = Course_Ta.query.filter_by(student_id=student_id).all()
    attendances = []
    for attendance_query in Attendance.query.filter_by(student_id=student_id).all():
        attendances.append({'id':len(attendances)+1,'date_posted':attendance_query.date_posted,
                            'datetime_posted':attendance_query.datetime_posted})
    student_data = {'name':student.name,'email':student.email, 'roll_number':student.roll_number,
                   'phone_number':student.phone_number, 'field':student.field,'alt_email':student.alt_email,
                    'program':student.program, 'hostel_no': student.hostel_no,'category':student.category,
                    'room_no': student.room_no}
    facads = Facad.query.filter_by(student_id=student_id).all()
    facad_list = []
    for facad in facads:
        facad_list.append({'status':facad.status,'facad_name':facad.facad.name})
    
    return render_template('studentData.html', student=student_data, course_tas=course_tas, attendances=attendances,facads = facad_list)

# Get Faculty List
@app.route("/facultyList")
@login_required
def facultyList():
    semester = Semester.query.all()
    facultys = [{'id':faculty.id,'name':faculty.__repr__()} for faculty in Faculty.query.all() if faculty.role != 'admin']
    return render_template("facultyList.html", facultys=facultys,semesters=semester)

# Get Faculty List Based on Semester
@app.route("/get_faculty_list", methods=["GET","POST"])
@login_required
def get_faculty_list():
    semester_id = request.form.get('semester_id')
    facultys = Faculty.query.all()
    max_faculty_id = max([f.id for f in facultys])
    f_status = [None]*(max_faculty_id+1)
    f_courses = [None]*(max_faculty_id+1)
    coordinator = [None]*(max_faculty_id+1)
    for f in Faculty_Semester.query.filter_by(semester_id=semester_id,is_active=0).all():
        f_status[f.faculty_id] = 1
    for f in Coordinator_Semester.query.filter_by(semester_id=semester_id).all():
        coordinator[f.faculty_id] = f.field
    for cf in Course_Faculty.query.filter_by(semester_id=semester_id).all():
        a = f_courses[cf.faculty_id]
        if a is None:
            a = []
        a.append(cf)
        f_courses[cf.faculty_id] = a
    faculty_list = []
    for faculty in facultys:
        # Checking Faculty Status
        status = ''
        if faculty.is_active == 0:
            status = 'Inactive'
        elif f_status[faculty.id] == 1:
            status = 'OnLeave'
        # Finding Courses Currently Taught by faculty
        courses = []
        a = f_courses[faculty.id]
        if a is None:
            a = []
        for c in a:
            courses.append({'id':c.course_id,'name':c.section+'-'+c.course.__repr__()})
        # Checking if coordinator
        coord = coordinator[faculty.id]
        if coord is None:
            coord = ""
        # Adding Entry to List
        faculty_list.append({'id':faculty.id, 'email':faculty.email,'ldap':faculty.ldap,
                            'name':faculty.name,'phone_number':faculty.phone_number,
                            'field':faculty.field,'courses': courses,'status':status,'coord':coord})
    resp = {'facultys':faculty_list}
    return jsonify(resp)

# Search Faculty Using Faculty name / Ldap
@app.route("/findFaculty" , methods=['GET', 'POST'])
@login_required
def findFaculty():
    faculty_id = request.args.get('faculty')
    return redirect(url_for('facultyData', faculty_id=faculty_id))

# Faculty Profile Page
@app.route("/facultyData/<faculty_id>")
@login_required
def facultyData(faculty_id):
    faculty = Faculty.query.get_or_404(faculty_id)
    faculty_list = {'email':faculty.email,'name':faculty.name,'phone_no':faculty.phone_number,
                    'field':faculty.field, 'status':faculty.is_active, 'ldap':faculty.ldap}
    facads = Facad.query.filter_by(facad_id = faculty_id).all()
    semester_data = []
    semesters = Semester.query.all()
    for sem in semesters:
        courses = Course_Faculty.query.filter_by(faculty_id=faculty_id,semester_id=sem.id).all()
        course_data = []
        for c in courses:
            course_tas = Course_Ta.query.filter_by(course_id=c.course_id,section=c.section,semester_id=sem.id).all()
            tas = [{'student_id':ta.student_id,'name':ta.ta.__repr__()} for ta in course_tas]
            course_data.append({'course_id':c.course_id,'code':c.course,'section':c.section,'tas':tas})
        if len(course_data) != 0:
            semester_data.append({'semester':sem.semester,'courses':course_data})
    return render_template('facultyData.html', faculty=faculty_list, facads = facads,semesters=semester_data)

# Get Course List
@app.route("/courseList")
@login_required
def courseList():
    semester = Semester.query.all()
    courses = [{'id':course.id,'name':course.__repr__()} for course in Course.query.all()]
    return render_template("courseList.html", courses=courses,semesters=semester)

# Get Course List Based on Semester
@app.route("/get_course_list", methods=["GET","POST"])
@login_required
def get_course_list():
    semester_id = request.form.get("semester_id")
    course_list = []
    courses = Course.query.all()
    course_ids = [c.id for c in courses]
    c_status = [0]*(max(course_ids)+1)
    c_sections = [None]*(max(course_ids)+1)
    for cs in Course_Semester.query.filter_by(semester_id=semester_id,is_mandatory=1).all():
        c_status[cs.course_id] = 1
    for cf in Course_Faculty.query.filter_by(semester_id=semester_id).all():
        a = c_sections[cf.course_id]
        if a is None:
            a = []
        a.append(cf)
        c_sections[cf.course_id] = a
    for course in courses:
        # Faculty associated with this course
        instructors = []
        a = c_sections[course.id]
        if a is None:
            a = []
        for s in a:
            instructors.append({'faculty_id':s.faculty_id,'name':s.faculty.name,'section':s.section,
                                'TA': str(Course_Ta.query.filter_by(course_id=course.id,semester_id=semester_id,section=s.section).count())+'/'+str(s.maxTA)})
        course_list.append({'id':course.id,'field':course.field,'code':course.code,'is_mandatory':c_status[course.id],
                            'name':course.name,'instructors':instructors})
    resp = {'courses':course_list}
    return jsonify(resp)

# Search Course Based on Code / Name
@app.route("/findCourse" , methods=['GET', 'POST'])
@login_required
def findCourse():
    course_id = request.args.get('course')
    return redirect(url_for('courseData', course_id=course_id))

# Course Profile Page
@app.route("/courseData/<course_id>")
@login_required
def courseData(course_id):
    course = Course.query.get(course_id)
    semesters = Semester.query.all()
    semester_data = []
    for sem in semesters:
        status = Course_Semester.query.filter_by(course_id=course.id,semester_id=sem.id,is_mandatory=1).first()
        # Course Status in Semester
        mandatory = ''
        if status:
            mandatory = str(status.is_mandatory)
        course_sections = Course_Faculty.query.filter_by(course_id=course_id,semester_id=sem.id).all()
        course_tas = Course_Ta.query.filter_by(course_id=course_id,semester_id=sem.id).all()
        sections = []
        for s in course_sections:
            tas = [{'student_id':ta.student_id,'name':ta.ta.__repr__()} for ta in course_tas if ta.section == s.section]
            sections.append({'section':s.section,'maxTA':s.maxTA,'faculty_id':s.faculty_id
                            ,'faculty':s.faculty.__repr__(),'tas':tas})
        if len(sections) != 0:
            semester_data.append({'semester':sem.semester,'sections':sections,'status':mandatory})
    course_data = {'code':course.code,'name':course.name,'field':course.field,
                    'semesters':semester_data}
    return render_template('courseData.html',course=course_data)


#
#
#
# Student Access Pages
# *********************
#
# Attendance Section for TAs
# ***************************
#
# Update Data and Add Facad
# **************************
#
#
#

# Student Access Page
@app.route("/attendance", methods = ["GET","POST"])
def attendance():
    student_id = int(request.args.get('student_id'))
    token = str(request.args.get('student_token'))
    student = Student_token.query.filter_by(student_id=student_id, token=token).first()

    # Checking for Valid Student Token and Student ID
    if student == None:
        flash('Invalid or Expired Token', 'info')
        return redirect(url_for('student_token'))

    s = Student.query.get(student_id)
    course_tas = Course_Ta.query.filter_by(student_id=student_id).all()
    attendances = []
    for attendance_query in Attendance.query.filter_by(student_id=student_id):
        attendances.append({'id':len(attendances)+1, 'date_posted':attendance_query.date_posted,
                            'datetime_posted':attendance_query.datetime_posted})
    facultys = [{'id':faculty.id, 'name':faculty.name} for faculty in Faculty.query.filter_by(is_active=1).all() if faculty.role != 'admin']
    student_data = {'id':student_id, 'token':token, 'name':s.name,'email':s.email,
                    'roll_number':s.roll_number,'phone_number':s.phone_number,'field':s.field,
                    'program':s.program, 'hostel_no': s.hostel_no,'room_no': s.room_no,
                    'alt_email':s.alt_email}
    fields = ['All', 'TFE', 'Manufacturing', 'Design']
    programs = ['BTech', 'MTech', 'Phd']
    return render_template("attendance.html", student=student_data, course_tas=course_tas, attendances=attendances,
                            facultys=facultys,fields=fields,programs=programs)

# Marking Attendance , Can be Marked once a Day
@app.route("/markAttendance", methods = ["GET","POST"])
def markAttendance():
    student_id = int(request.args.get('student_id'))
    student_token = str(request.args.get('student_token'))
    date_posted=datetime.datetime.now(pytz.timezone('Asia/Kolkata')).date()
    datetime_posted = datetime.datetime.now(pytz.timezone('Asia/Kolkata')).today()
    prev_attendance = Attendance.query.filter_by(student_id=student_id,date_posted=date_posted).first()
    if prev_attendance:
        flash("You have already marked your attendance", "info")
    else:
        attendance = Attendance(student_id=student_id,date_posted=date_posted,datetime_posted=datetime_posted)
        db.session.add(attendance)
        student = Student.query.get(student_id)
        student.last_attendance = date_posted
        db.session.commit()
        flash("Attendace Marked !", "success")
    return redirect(url_for('attendance', student_id=student_id, student_token=student_token))

# Editing Student Phone, Hostel, Room, Alt_email, Program, Field
@app.route("/editStudentData", methods = ["GET","POST"])
def editStudentData():
    student_id = request.form.get('student_id')
    student = Student.query.filter_by(id=student_id).first()
    student.phone_number = request.form.get('phone_number')
    student.hostel_no = request.form.get('hostel_no')
    student.room_no = request.form.get('room_no')
    student.alt_email = request.form.get('alt_email')
    field = request.form.get('field')
    if field in get_fields(0):
        student.field = field
    else:
        db.session.rollback()
        resp = {'message': 'error'}
        return jsonify(resp)
    student.program = request.form.get('program')
    try:
        db.session.commit()
        resp = {'message':'success'}
    except:
        db.session.rollback()
        resp = {'message': 'error'}
    return jsonify(resp)

# Fetching Faculty Advisors List
@app.route("/getFacadData", methods = ["GET","POST"])
def getFacadData():
    student_id = request.form.get('student_id')
    facads = Facad.query.filter_by(student_id=student_id).all()
    facad_list = []
    for facad in facads:
        facad_list.append({'id':facad.id,'status':facad.status,'facad_name':facad.facad.name})
    resp = {'facads':facad_list}
    return jsonify(resp)

# Removing Facad Allotment
@app.route("/facadRemove", methods = ["GET","POST"])
def facadRemove():
    facad_id = request.form.get('facad_id')
    student_id = request.form.get('student_id')
    facad = Facad.query.filter_by(id=facad_id, student_id=student_id).first()
    resp = {}
    if facad:
        db.session.delete(facad)
        resp = {'message':'Removed'}
    db.session.commit()
    return jsonify(resp)

# Adding Faculty Advisor
@app.route("/addFacad", methods = ["GET","POST"])
def addFacad():
    facad_id = request.form.get('facad_id')
    status = request.form.get('status')
    student_id = request.form.get('student_id')
    facad = Facad(student_id=student_id,facad_id=facad_id,status=status)
    facad_check = Facad.query.filter_by(student_id=student_id,facad_id=facad_id).first()
    if facad_check:
        resp = {'message': 'Entry already exists'}
        return jsonify(resp)

    if status=='secondary':
        db.session.add(facad)
        resp = {'message': 'Added'}
    if status=='primary':
        facad_primary = Facad.query.filter_by(student_id=student_id,status='primary').first()
        if facad_primary:
            resp = {'message': 'Only 1 primary Facad is Allowed'}
        else:
            db.session.add(facad)
            resp = {'message': 'Added'}
    try:
        db.session.commit()
    except:
        db.session.rollback()
        resp = {'message': 'Error'}

    return jsonify(resp)


# ==========================================================
# ==========================================================
# ==========================================================